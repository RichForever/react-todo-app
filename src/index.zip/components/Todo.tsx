import React from 'react';
import TodoWrapper from "./TodoWrapper";

const Todo = () => {
    return (
        <div>
            <TodoWrapper />
        </div>
    );
};

export default Todo;